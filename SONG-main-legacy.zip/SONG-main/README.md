# SONG
Secure Object Notation Gateway

FIRSTLY LEVERAGES THE FOLLOWING

VENI -> Fill data based on what is "missing" from form data as a GET and returns a HTML form

VIDI -> Saves data in HBSMST key value scheme (Head,Body,Tail,Mark,Sign,Time)