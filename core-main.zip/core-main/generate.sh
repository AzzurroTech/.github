echo "Purging directories from the stack..."
rm -r SONG
rm -r POD
rm -r vici
rm -r veni
rm -r vidi
echo "Pulling required repos from GIT to build our stack..."
git clone https://github.com/AzzurroTech/POD.git
git clone https://github.com/AzzurroTech/SONG.git
git clone https://github.com/Emperor42/vici.git
git clone https://github.com/Emperor42/veni.git
git clone https://github.com/Emperor42/vidi.git