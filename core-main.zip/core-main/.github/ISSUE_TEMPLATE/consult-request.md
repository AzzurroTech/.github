---
name: Consult request
about: Book a consultation with our team
title: "[REQUEST]"
labels: help wanted
assignees: Emperor42

---

**Do you have a software problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**What is your budget?**
What is your budget per week/month/year?

**What is your deadline?**
When do you want to have a working system?

**Additional context**
Add any other context or screenshots about the feature request here.
